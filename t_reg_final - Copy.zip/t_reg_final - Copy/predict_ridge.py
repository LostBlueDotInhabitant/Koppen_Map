"""Predict the local temperature of every 1-degree pixel for one year and compare with the real values.

Run:  python predict_ridge.py 2050 --scenario ssp245
      python predict_ridge.py            (asks for the year)
Needs: kernelize.py, ridge_temperature_model.joblib and ridge_temperature_model_meta.json (from train_ridge.py).
"""
import argparse
import json

import joblib
import numpy as np

import kernelize as kz

# ----------------------------- settings (edit these) -----------------------------
DATA_DIRECTORY = "data_cache"   # same folder as in train_ridge.py
GITHUB_BASE_URL = None

MODEL_FILE = "ridge_temperature_model.joblib"
METADATA_FILE = "ridge_temperature_model_meta.json"
SAVE_PREDICTION_ARRAY = True      # also write predictions_<scenario>_<year>.npy, shape (180, 360), in C


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("year", nargs="?", type=int, help="year between 1900 and 2099")
    parser.add_argument("--scenario", default="ssp245", choices=kz.ALL_SCENARIOS,
                        help="SSP scenario (only matters for years >= 2015)")
    args = parser.parse_args()
    year = args.year if args.year is not None else int(input("Year to predict (1900-2099): "))
    if not 1900 <= year <= 2099:
        raise SystemExit("Year must be between 1900 and 2099.")
    scenario = args.scenario
    label = "historical" if year <= 2014 else scenario

    with open(METADATA_FILE) as f:
        meta = json.load(f)
    model = joblib.load(MODEL_FILE)
    kz.configure_data_sources(github_base_url=GITHUB_BASE_URL, temperature_directory=DATA_DIRECTORY)
    kz.configure_kernel(kernel_size=meta["kernel_size"],
                        water_vector_kernel_size=meta["water_vector_kernel_size"],
                        water_inverse_distance_power=meta["water_inverse_distance_power"])

    print(f"Loading data for {year} ({label})...")
    real_grid = kz.load_local_temperature_grids_by_year(scenario, year, year)[year]        # (180, 360), C
    temperature_by_year, co2_by_year = kz.load_global_mean_temperature_and_co2_by_year(scenario, year)

    X = kz.make_temperature_regression_features(meta["kernel_size"], temperature_by_year[year], co2_by_year[year])
    if X.shape[1] != meta["n_features"]:
        raise SystemExit(f"Feature count {X.shape[1]} != {meta['n_features']} the model was trained with; "
                         "retrain with the current kernelize.py.")
    predicted_grid = kz.reshape_predictions_to_grid(model.predict(X))                       # (180, 360), C
    if SAVE_PREDICTION_ARRAY:
        out_name = f"predictions_{label}_{year}.npy"
        np.save(out_name, predicted_grid)
        print(f"Saved prediction array to {out_name}")

    error_c = (predicted_grid - real_grid).ravel().astype(np.float64)                       # signed error in C
    # Percent error is taken in KELVIN: in Celsius, pixels near 0 C would divide by ~0 and blow up.
    real_k = real_grid.ravel().astype(np.float64) + 273.15
    error_pct = 100.0 * error_c / real_k

    print(f"\nResults for {year} over {error_c.size:,} pixels")
    print(f"  Mean error (bias):         {error_c.mean():+.3f} C   |  {error_pct.mean():+.4f} %")
    print(f"  Std dev of error:          {error_c.std():.3f} C   |  {error_pct.std():.4f} %")
    print(f"  Mean absolute error:       {np.abs(error_c).mean():.3f} C   |  {np.abs(error_pct).mean():.4f} %")
    print(f"  RMSE:                      {np.sqrt((error_c ** 2).mean()):.3f} C")
    print(f"  Global mean  real: {real_grid.mean():.2f} C   predicted: {predicted_grid.mean():.2f} C")

    if meta.get("split_mode") == "years":
        held_out = year % meta["holdout_every"] == 0
        print(f"\nThis year was {'HELD OUT of training (honest test)' if held_out else 'part of the training data (optimistic)'}.")
    else:
        print("\nNote: training used a random row split, so this year's pixels were probably partly in the "
              "training data; these numbers are optimistic.")


if __name__ == "__main__":
    main()
