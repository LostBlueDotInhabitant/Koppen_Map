"""Train a ridge regression that predicts mean local temperature from 11x11 kernels, water/ice vectors and location.

Run:  python train_ridge.py
Needs: numpy, pandas, scikit-learn, joblib, and kernelize.py in the same folder.
"""
import json
import time

import joblib
import numpy as np
from sklearn.linear_model import RidgeCV
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

import kernelize as kz

# ----------------------------- settings (edit these) -----------------------------
# Folder holding ALL five CSVs (MapVariables, the two co2_temperature files, and the two temperature files).
DATA_DIRECTORY = "data_cache"
GITHUB_BASE_URL = None            # only needed if MapVariables/co2 files are NOT in DATA_DIRECTORY

KERNEL_SIZE = 11                  # 11x11 neighbourhood around each label pixel
WATER_VECTOR_KERNEL_SIZE = 9      # window used for the water / ice vectors
WATER_INVERSE_DISTANCE_POWER = 2

# Features = 11*11*4 kernel + 12 water/ice vectors + 8 location + 2 global = 506 columns (float32).
# Rows = pixels_per_year x ~710 year-slots.  1,000 px/year ~ 1.4 GB for X (training peaks at ~3x that).
PIXELS_PER_YEAR = 1000

# "years": every HOLDOUT_EVERY-th year is held out completely (an honest test: neighbouring pixels and
#          adjacent years are near-duplicates, so a random row split leaks).
# "random": random rows, as in random_train_test_split (optimistic scores).
SPLIT_MODE = "years"
HOLDOUT_EVERY = 5
TEST_FRACTION = 0.2               # only used when SPLIT_MODE == "random"
RANDOM_SEED = 0
ALPHAS = np.logspace(-3, 4, 15)   # RidgeCV picks the best regularization strength from these

MODEL_FILE = "ridge_temperature_model.joblib"
METADATA_FILE = "ridge_temperature_model_meta.json"


def main():
    kz.configure_data_sources(github_base_url=GITHUB_BASE_URL, temperature_directory=DATA_DIRECTORY)
    kz.configure_kernel(kernel_size=KERNEL_SIZE,
                        water_vector_kernel_size=WATER_VECTOR_KERNEL_SIZE,
                        water_inverse_distance_power=WATER_INVERSE_DISTANCE_POWER)

    print("Building dataset (all 7 scenarios + historical)...")
    t0 = time.time()
    X, y, year_of_row, scenario_of_row = kz.make_temperature_regression_training_data_from_files(
        pixels_per_year=PIXELS_PER_YEAR, random_seed=RANDOM_SEED)
    print(f"  X: {X.shape} ({X.dtype}, {X.nbytes / 1e9:.2f} GB)  [{time.time() - t0:.0f}s]")

    if SPLIT_MODE == "years":
        is_test = (year_of_row % HOLDOUT_EVERY == 0)
        X_train, y_train, X_test, y_test = X[~is_test], y[~is_test], X[is_test], y[is_test]
        scen_test = scenario_of_row[is_test]
        split_note = f"years divisible by {HOLDOUT_EVERY} held out"
    else:
        X_train, y_train, X_test, y_test, _, _, _, scen_test = \
            kz.random_train_test_split(X, y, TEST_FRACTION, RANDOM_SEED, year_of_row, scenario_of_row)
        split_note = f"random {TEST_FRACTION:.0%} of rows held out"
    n_features = X.shape[1]
    del X  # free memory
    print(f"  train rows: {len(y_train):,}   test rows: {len(y_test):,}   ({split_note})")

    # Ridge penalizes all coefficients equally, so features must be on the same scale:
    # StandardScaler inside the pipeline handles that and is saved with the model.
    model = make_pipeline(StandardScaler(), RidgeCV(alphas=ALPHAS))
    print("Training ridge (RidgeCV chooses alpha by efficient leave-one-out)...")
    t0 = time.time()
    model.fit(X_train, y_train)
    best_alpha = float(model[-1].alpha_)
    print(f"  best alpha = {best_alpha:g}  [{time.time() - t0:.0f}s]")
    if best_alpha in (ALPHAS[0], ALPHAS[-1]):
        print("  WARNING: best alpha is at the edge of the grid; widen ALPHAS.")

    def report(name, X_, y_):
        pred = model.predict(X_)
        rmse = mean_squared_error(y_, pred) ** 0.5
        print(f"  {name:<10} R2={r2_score(y_, pred):.4f}  RMSE={rmse:.3f} C  MAE={mean_absolute_error(y_, pred):.3f} C")
        return pred

    print("Evaluation:")
    report("train", X_train, y_train)
    test_pred = report("test", X_test, y_test)

    print("Test RMSE by scenario:")
    for scenario in np.unique(scen_test):
        m = scen_test == scenario
        print(f"  {scenario:<11} {mean_squared_error(y_test[m], test_pred[m]) ** 0.5:.3f} C  (n={m.sum():,})")

    joblib.dump(model, MODEL_FILE, compress=3)
    metadata = {
        "model_file": MODEL_FILE,
        "kernel_size": KERNEL_SIZE,
        "water_vector_kernel_size": WATER_VECTOR_KERNEL_SIZE,
        "water_inverse_distance_power": WATER_INVERSE_DISTANCE_POWER,
        "n_features": int(n_features),
        "feature_layout": "kernel(k*k*4: altitude, ice thickness, land fraction, ice fraction) + 12 water/ice "
                          "vector columns + 8 location columns + global mean temp + CO2 ppm",
        "split_mode": SPLIT_MODE,
        "holdout_every": HOLDOUT_EVERY if SPLIT_MODE == "years" else None,
        "best_alpha": best_alpha,
        "pixels_per_year": PIXELS_PER_YEAR,
        "test_r2": float(r2_score(y_test, test_pred)),
        "test_rmse_C": float(mean_squared_error(y_test, test_pred) ** 0.5),
    }
    with open(METADATA_FILE, "w") as f:
        json.dump(metadata, f, indent=2)
    print(f"Saved model to {MODEL_FILE} and settings to {METADATA_FILE}")


if __name__ == "__main__":
    main()
