#!/usr/bin/env python3
"""
Quick check that LightGBM can train on your NVIDIA GPU (native Windows: through OpenCL).

    python check_gpu.py

It prints the OpenCL GPUs LightGBM can see, then times the same small multiclass training on CPU and GPU.
If it says no GPU was found, see the troubleshooting list in the setup instructions.
"""
import platform
import sys
import time

import lightgbm as lgb
import numpy as np

from koppen_train import IS_WINDOWS, PREFERRED_GPU_VENDOR, find_opencl_devices


def timed_fit(device, gpu_platform_id=None, rows=300_000, feats=30, classes=12, rounds=40):
    r = np.random.default_rng(0)
    X = r.random((rows, feats)).astype(np.float32)
    y = r.integers(0, classes, rows)
    params = dict(objective="multiclass", num_class=classes, num_leaves=63, learning_rate=0.1,
                  device_type=device, verbosity=-1)
    if gpu_platform_id is not None:
        params["gpu_platform_id"] = gpu_platform_id
    t0 = time.time()
    lgb.train(params, lgb.Dataset(X, y), num_boost_round=rounds)
    return time.time() - t0


def main():
    print(f"Python {sys.version.split()[0]} ({platform.architecture()[0]}) on {platform.system()}")
    print(f"LightGBM {lgb.__version__}")
    if IS_WINDOWS:
        print("Windows: GPU runs through OpenCL (LightGBM's CUDA backend does not exist on Windows).")

    devices = find_opencl_devices()
    if not devices:
        print("\nNO OpenCL GPU found by LightGBM. Checklist:")
        print("  1. Update the NVIDIA driver (Game Ready or Studio), then reboot.  Test:  nvidia-smi")
        print("  2. Use 64-bit Python and:  pip install --upgrade lightgbm")
        print("  3. Install the Microsoft Visual C++ Redistributable (x64) if Visual Studio is not installed.")
        print("  4. Laptop with two GPUs: set python.exe to 'High performance NVIDIA processor' in")
        print("     Windows Settings > System > Display > Graphics.")
        sys.exit(1)

    print("\nOpenCL devices LightGBM can use:")
    for pid, desc in devices:
        print(f"  platform {pid}: {desc}")
    pick = next((pid for pid, d in devices if PREFERRED_GPU_VENDOR.lower() in d.lower()), None)
    if pick is None:
        print(f"\nNo '{PREFERRED_GPU_VENDOR}' device among them; timing platform {devices[0][0]} instead.")
        pick = devices[0][0]

    print("\nTiming 300,000 rows x 30 features, 12 classes, 40 rounds ...")
    t_cpu = timed_fit("cpu")
    print(f"  CPU : {t_cpu:6.1f} s")
    t_gpu = timed_fit("gpu", pick)
    print(f"  GPU : {t_gpu:6.1f} s   (platform {pick})")
    print("\nGPU training works." if t_gpu > 0 else "")
    print(f"Run training with:  python koppen_train.py --out out --device gpu --gpu-platform-id {pick}")
    print("(or leave out --device / --gpu-platform-id: 'auto' finds this GPU by itself)")


if __name__ == "__main__":
    main()
