"""Training pipeline for local mean temperature (v4).

Changes vs v3:
  * latitude/longitude features added (kz.configure_kernel(include_coordinates=True)) -- v3 had no way to know
    where a pixel was, so it could not learn the equator-to-pole gradient;
  * nonlinear gradient-boosted trees (HistGradientBoostingRegressor) instead of a purely linear model, so
    latitude x ice x altitude x global-warming interactions can be learned;
  * the plain Ridge model (now with coordinates) is kept as a baseline;
  * an extrapolation check: train on years < EXTRAPOLATION_CUTOFF_YEAR, test on later years.
"""

import joblib
import numpy as np
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_absolute_error, root_mean_squared_error
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

import kernelize as kz

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
GITHUB_BASE_URL = "https://raw.githubusercontent.com/LostBlueDotInhabitant/Koppen_Map/refs/heads/main/"
TEMPERATURE_DIR = "TemperaturePerLocation"
CACHE_DIR = "data_cache"

KERNEL_SIZE = 5
WATER_VECTOR_KERNEL_SIZE = 9
INCLUDE_WATER_VECTORS = True
INVERSE_DISTANCE_POWER = 1
WATER_INVERSE_DISTANCE_POWER = 2
SCALE_EW_BY_COS_LAT = False
INCLUDE_COORDINATES = True          # the key fix

SCENARIOS = kz.ALL_SCENARIOS
YEARS = range(1900, 2100)
PIXELS_PER_YEAR = 5000
TEST_FRACTION = 0.2
SPLIT_SEED = 0
MODEL_OUTPUT_PATH = "temp_regressor_hgb_k5_w9_coords.joblib"

CHECK_EXTRAPOLATION = True          # costs one extra fit
EXTRAPOLATION_CUTOFF_YEAR = 2070


def kernel_settings():
    return {
        "kernel_size": KERNEL_SIZE,
        "water_vector_kernel_size": WATER_VECTOR_KERNEL_SIZE,
        "include_water_vectors": INCLUDE_WATER_VECTORS,
        "inverse_distance_power": INVERSE_DISTANCE_POWER,
        "water_inverse_distance_power": WATER_INVERSE_DISTANCE_POWER,
        "scale_east_west_by_cos_latitude": SCALE_EW_BY_COS_LAT,
        "include_coordinates": INCLUDE_COORDINATES,
    }


def configure_pipeline():
    kz.configure_data_sources(
        github_base_url=GITHUB_BASE_URL,
        temperature_directory=TEMPERATURE_DIR,
        cache_directory=CACHE_DIR,
    )
    kz.configure_kernel(**kernel_settings())


def make_models():
    return {
        "Ridge (alpha=10.0)": make_pipeline(StandardScaler(), Ridge(alpha=10.0)),
        "HistGradientBoosting": HistGradientBoostingRegressor(
            max_iter=600,
            learning_rate=0.08,
            max_leaf_nodes=63,
            min_samples_leaf=40,
            l2_regularization=1.0,
            early_stopping=True,
            validation_fraction=0.1,
            n_iter_no_change=25,
            random_state=0,
        ),
    }


def build_datasets():
    configure_pipeline()
    X, y, year_of_row, scenario_of_row = kz.make_temperature_regression_training_data_from_files(
        kernel_size=None,
        scenarios=SCENARIOS,
        years=YEARS,
        pixels_per_year=PIXELS_PER_YEAR,
        global_temperature_from="file",
    )
    return X, y, year_of_row, scenario_of_row


def report(name, y_true, y_pred, label):
    mae = mean_absolute_error(y_true, y_pred)
    rmse = root_mean_squared_error(y_true, y_pred)
    print(f"{name:22s} [{label}] MAE: {mae:.4f} C | RMSE: {rmse:.4f} C")
    return rmse


def main():
    X, y, year_of_row, _ = build_datasets()
    print(f"Training matrix: {X.shape}")

    # 1) random split (same as v3) to pick the best model
    X_train, y_train, X_test, y_test, *_ = kz.random_train_test_split(X, y, TEST_FRACTION, SPLIT_SEED)
    best_name, best_rmse = None, float("inf")
    for name, model in make_models().items():
        model.fit(X_train, y_train)
        rmse = report(name, y_test, model.predict(X_test), "random split")
        if rmse < best_rmse:
            best_name, best_rmse = name, rmse
    print(f"Selected best model: {best_name}")

    # 2) honest future check: fit on the past only, test on years the model never saw
    if CHECK_EXTRAPOLATION:
        past = year_of_row < EXTRAPOLATION_CUTOFF_YEAR
        model = make_models()[best_name]
        model.fit(X[past], y[past])
        report(best_name, y[~past], model.predict(X[~past]), f"train <{EXTRAPOLATION_CUTOFF_YEAR}, test >={EXTRAPOLATION_CUTOFF_YEAR}")

    # 3) final model: refit on ALL data
    final_model = make_models()[best_name]
    final_model.fit(X, y)

    joblib.dump({"model": final_model, "kernel_settings": kernel_settings()}, MODEL_OUTPUT_PATH)
    print(f"Saved trained model to {MODEL_OUTPUT_PATH}")


if __name__ == "__main__":
    main()
