"""Inference script (v4): predict a global local-temperature grid from a saved .joblib model."""

import joblib
import numpy as np

import kernelize as kz

GITHUB_BASE_URL = "https://raw.githubusercontent.com/LostBlueDotInhabitant/Koppen_Map/refs/heads/main/"
TEMPERATURE_DIR = "TemperaturePerLocation"
CACHE_DIR = "data_cache"
MODEL_PATH = "temp_regressor_hgb_k5_w9_coords.joblib"

TARGET_YEAR = 2075
SCENARIO = "ssp245"
EPOCH = "0ka"
COMPARE_WITH_ACTUAL = True
OUTPUT_GRID_PATH = f"predicted_temp_{SCENARIO}_{TARGET_YEAR}.npy"


def load_model_and_configure(model_path=MODEL_PATH):
    bundle = joblib.load(model_path)
    kz.configure_data_sources(
        github_base_url=GITHUB_BASE_URL,
        temperature_directory=TEMPERATURE_DIR if COMPARE_WITH_ACTUAL else None,
        cache_directory=CACHE_DIR,
    )
    kz.configure_kernel(**bundle["kernel_settings"])   # includes include_coordinates
    return bundle["model"]


def predict_global_grid(model, target_year, scenario=SCENARIO, epoch=EPOCH):
    global_temp_by_year, co2_by_year = kz.load_global_mean_temperature_and_co2_by_year(
        scenario=scenario, last_year=target_year
    )
    X_grid = kz.make_temperature_regression_features(
        kernel_size=None,
        global_mean_temperature=global_temp_by_year[target_year],
        co2_ppm=co2_by_year[target_year],
        epoch=epoch,
    )
    return kz.reshape_predictions_to_grid(model.predict(X_grid))


def compare_with_actual_grid(pred_grid, target_year, scenario=SCENARIO):
    actual = kz.load_local_temperature_grids_by_year(
        scenario=scenario, first_year=target_year, last_year=target_year
    )[target_year].astype(np.float64)
    diff = pred_grid.astype(np.float64) - actual

    print(f"RMSE: {np.sqrt(np.mean(diff ** 2)):.3f} C | MAE: {np.mean(np.abs(diff)):.3f} C | "
          f"bias (pred - actual): {diff.mean():+.3f} C | std of diff: {diff.std():.3f} C")
    print(f"Area-weighted global mean: predicted {kz.compute_area_weighted_global_mean(pred_grid):.2f} C, "
          f"actual {kz.compute_area_weighted_global_mean(actual):.2f} C")

    print("Zonal mean (pred / actual) by latitude:")
    for lat in (-85, -60, -30, 0, 30, 60, 85):
        i = int(lat + 89.5)
        print(f"  {lat:+4d}: {pred_grid[i].mean():7.2f} / {actual[i].mean():7.2f} C")


def main():
    model = load_model_and_configure(MODEL_PATH)
    pred_grid = predict_global_grid(model, TARGET_YEAR, SCENARIO, EPOCH)

    np.save(OUTPUT_GRID_PATH, pred_grid)
    print(f"Predicted {TARGET_YEAR} ({SCENARIO}) global grid shape: {pred_grid.shape}")
    print(f"Min/Max predicted temperature: {pred_grid.min():.2f} C / {pred_grid.max():.2f} C")
    print(f"Saved predicted grid to {OUTPUT_GRID_PATH}")

    if COMPARE_WITH_ACTUAL:
        compare_with_actual_grid(pred_grid, TARGET_YEAR, SCENARIO)


if __name__ == "__main__":
    main()
