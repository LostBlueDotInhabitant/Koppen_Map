"""Predict the local temperature of every 1-degree pixel for one year and compare with the real values.

Altitude handling: each pixel is classified as LAND or OCEAN. The altitude-related features of land pixels are
amplified (mountains matter a lot), and those of ocean pixels are shrunk to almost nothing (seabed depth is
irrelevant to surface temperature). kernelize.py is NOT modified.

Run:  python predict_ridge.py 2050 --scenario ssp245
      python predict_ridge.py            (asks for the year)
      python predict_ridge.py --diagnose (prints what the script found in kernelize.py, then exits)
Needs: kernelize.py, ridge_temperature_model.joblib and ridge_temperature_model_meta.json (from train_ridge.py).
"""
import argparse
import json

import joblib
import numpy as np

import kernelize as kz

# ----------------------------- settings (edit these) -----------------------------
DATA_DIRECTORY = "data_cache"   # same folder as in train_ridge.py
GITHUB_BASE_URL = None

MODEL_FILE = "ridge_temperature_model.joblib"
METADATA_FILE = "ridge_temperature_model_meta.json"
SAVE_PREDICTION_ARRAY = True      # also write predictions_<scenario>_<year>.npy, shape (180, 360), in C

# How much the altitude features count. 1.0 = exactly as trained.
LAND_ALTITUDE_WEIGHT = 3.0        # land: mountains matter a lot (raise it for stronger mountains)
OCEAN_ALTITUDE_WEIGHT = 0.02      # ocean: altitude/depth is almost ignored

# Where to get the elevation grid (180, 360), metres, ocean negative / land positive (ETOPO style).
# None = search kernelize.py for it automatically. Or give a .npy path, e.g. "elevation_180x360.npy".
ELEVATION_NPY_FILE = None
# Land/ocean mask: None = use the mask from kernelize.py if one exists, otherwise elevation > 0 means land.
LAND_MASK_NPY_FILE = None
# Which feature columns are altitude features. None = read meta["altitude_columns"] if present, otherwise
# detect automatically (columns that track the elevation grid with |correlation| >= threshold).
ALTITUDE_COLUMNS = None           # e.g. list(range(0, 49)) if you know the indices
AUTO_DETECT_CORRELATION = 0.85
# ---------------------------------------------------------------------------------


def _as_grid(value):
    """Return value as a float (180, 360) array if it looks like one, else None."""
    try:
        arr = np.asarray(value, dtype=np.float64)
    except (TypeError, ValueError):
        return None
    if arr.size == 180 * 360 and arr.ndim in (1, 2):
        return arr.reshape(180, 360)
    return None


def _candidates(keywords):
    """Names in kernelize.py containing any keyword, as (name, object)."""
    return [(n, getattr(kz, n)) for n in dir(kz)
            if not n.startswith("__") and any(k in n.lower() for k in keywords)]


def _try_get_grid(obj):
    grid = _as_grid(obj) if not callable(obj) else None
    if grid is None and callable(obj):
        try:
            grid = _as_grid(obj())
        except Exception:
            grid = None
    return grid


def find_elevation_grid():
    if ELEVATION_NPY_FILE:
        grid = _as_grid(np.load(ELEVATION_NPY_FILE))
        if grid is None:
            raise SystemExit(f"{ELEVATION_NPY_FILE} must hold 64,800 values (180 x 360).")
        return grid, f"file {ELEVATION_NPY_FILE}"
    for name, obj in _candidates(("elev", "altitude", "topo", "height", "orography")):
        grid = _try_get_grid(obj)
        if grid is not None:
            return grid, f"kernelize.{name}"
    names = [n for n, _ in _candidates(("elev", "altitude", "topo", "height", "orography", "land", "mask"))]
    raise SystemExit("Could not find an elevation grid in kernelize.py automatically.\n"
                     f"Related names I can see there: {names or 'none'}.\n"
                     "Set ELEVATION_NPY_FILE at the top of this file to a (180, 360) .npy of elevation in metres, "
                     "or tell me the function/variable name in kernelize.py that returns it.")


def find_land_mask(elevation):
    if LAND_MASK_NPY_FILE:
        grid = _as_grid(np.load(LAND_MASK_NPY_FILE))
        if grid is not None:
            return grid > 0.5, f"file {LAND_MASK_NPY_FILE}"
    for name, obj in _candidates(("land", "mask")):
        grid = _try_get_grid(obj)
        if grid is not None and set(np.unique(grid)) <= {0.0, 1.0}:
            return grid > 0.5, f"kernelize.{name}"
    return elevation > 0.0, "elevation > 0 (no land mask found in kernelize.py)"


def find_altitude_columns(X, elevation_flat, meta):
    if ALTITUDE_COLUMNS is not None:
        return np.asarray(ALTITUDE_COLUMNS, dtype=int), "ALTITUDE_COLUMNS setting"
    if meta.get("altitude_columns"):
        return np.asarray(meta["altitude_columns"], dtype=int), "metadata file"
    e = elevation_flat - elevation_flat.mean()
    e_norm = np.sqrt((e ** 2).sum())
    Xc = X - X.mean(axis=0)
    denom = np.sqrt((Xc ** 2).sum(axis=0)) * e_norm
    with np.errstate(divide="ignore", invalid="ignore"):
        corr = np.where(denom > 0, (Xc * e[:, None]).sum(axis=0) / denom, 0.0)
    cols = np.where(np.abs(corr) >= AUTO_DETECT_CORRELATION)[0]
    return cols, f"auto-detected (|corr with elevation| >= {AUTO_DETECT_CORRELATION})"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("year", nargs="?", type=int, help="year between 1900 and 2099")
    parser.add_argument("--scenario", default="ssp245", choices=kz.ALL_SCENARIOS,
                        help="SSP scenario (only matters for years >= 2015)")
    parser.add_argument("--diagnose", action="store_true", help="show what was found in kernelize.py and exit")
    args = parser.parse_args()
    if args.diagnose:
        print("Names in kernelize.py related to elevation / land:")
        for n, o in _candidates(("elev", "altitude", "topo", "height", "orography", "land", "mask")):
            print(f"  {n}  ({type(o).__name__})")
        elevation, src = find_elevation_grid()
        print(f"Elevation grid from {src}: min {elevation.min():.0f} m, max {elevation.max():.0f} m")
        land, lsrc = find_land_mask(elevation)
        print(f"Land mask from {lsrc}: {land.mean() * 100:.1f}% of pixels are land")
        return
    year = args.year if args.year is not None else int(input("Year to predict (1900-2099): "))
    if not 1900 <= year <= 2099:
        raise SystemExit("Year must be between 1900 and 2099.")
    scenario = args.scenario
    label = "historical" if year <= 2014 else scenario

    with open(METADATA_FILE) as f:
        meta = json.load(f)
    model = joblib.load(MODEL_FILE)
    kz.configure_data_sources(github_base_url=GITHUB_BASE_URL, temperature_directory=DATA_DIRECTORY)
    kz.configure_kernel(kernel_size=meta["kernel_size"],
                        water_vector_kernel_size=meta["water_vector_kernel_size"],
                        water_inverse_distance_power=meta["water_inverse_distance_power"])

    print(f"Loading data for {year} ({label})...")
    real_grid = kz.load_local_temperature_grids_by_year(scenario, year, year)[year]        # (180, 360), C
    temperature_by_year, co2_by_year = kz.load_global_mean_temperature_and_co2_by_year(scenario, year)

    X = kz.make_temperature_regression_features(meta["kernel_size"], temperature_by_year[year], co2_by_year[year])
    if X.shape[1] != meta["n_features"]:
        raise SystemExit(f"Feature count {X.shape[1]} != {meta['n_features']} the model was trained with; "
                         "retrain with the current kernelize.py.")

    # ---- land / ocean detection and altitude re-weighting ----
    elevation, elev_src = find_elevation_grid()
    land_grid, land_src = find_land_mask(elevation)
    land = land_grid.ravel()
    if land.size != X.shape[0]:
        raise SystemExit(f"Elevation grid has {land.size} pixels but there are {X.shape[0]} feature rows.")
    alt_cols, cols_src = find_altitude_columns(X, elevation.ravel(), meta)
    if alt_cols.size == 0:
        raise SystemExit("No altitude feature columns found. Set ALTITUDE_COLUMNS at the top of this file, "
                         "or lower AUTO_DETECT_CORRELATION.")
    print(f"Elevation: {elev_src} | land mask: {land_src} ({land.mean() * 100:.1f}% land)")
    print(f"Altitude columns: {alt_cols.size} ({cols_src}) | weights: land x{LAND_ALTITUDE_WEIGHT}, "
          f"ocean x{OCEAN_ALTITUDE_WEIGHT}")

    X = np.array(X, dtype=np.float64, copy=True)
    row_weight = np.where(land, LAND_ALTITUDE_WEIGHT, OCEAN_ALTITUDE_WEIGHT)               # per pixel
    X[:, alt_cols] *= row_weight[:, None]

    predicted_grid = kz.reshape_predictions_to_grid(model.predict(X))                       # (180, 360), C
    if SAVE_PREDICTION_ARRAY:
        out_name = f"predictions_{label}_{year}.npy"
        np.save(out_name, predicted_grid)
        print(f"Saved prediction array to {out_name}")

    error_c = (predicted_grid - real_grid).ravel().astype(np.float64)                       # signed error in C
    # Percent error is taken in KELVIN: in Celsius, pixels near 0 C would divide by ~0 and blow up.
    real_k = real_grid.ravel().astype(np.float64) + 273.15
    error_pct = 100.0 * error_c / real_k

    def report(title, mask):
        e, p = error_c[mask], error_pct[mask]
        print(f"  {title:<8} MAE {np.abs(e).mean():.3f} C | bias {e.mean():+.3f} C | RMSE {np.sqrt((e ** 2).mean()):.3f} C"
              f" | MAE {np.abs(p).mean():.4f} %")

    print(f"\nResults for {year} over {error_c.size:,} pixels")
    print(f"  Mean error (bias):         {error_c.mean():+.3f} C   |  {error_pct.mean():+.4f} %")
    print(f"  Std dev of error:          {error_c.std():.3f} C   |  {error_pct.std():.4f} %")
    print(f"  Mean absolute error:       {np.abs(error_c).mean():.3f} C   |  {np.abs(error_pct).mean():.4f} %")
    print(f"  RMSE:                      {np.sqrt((error_c ** 2).mean()):.3f} C")
    print(f"  Global mean  real: {real_grid.mean():.2f} C   predicted: {predicted_grid.mean():.2f} C")
    print("\nBy surface type:")
    report("Land", land)
    report("Ocean", ~land)

    if meta.get("split_mode") == "years":
        held_out = year % meta["holdout_every"] == 0
        print(f"\nThis year was {'HELD OUT of training (honest test)' if held_out else 'part of the training data (optimistic)'}.")
    else:
        print("\nNote: training used a random row split, so this year's pixels were probably partly in the "
              "training data; these numbers are optimistic.")


if __name__ == "__main__":
    main()
